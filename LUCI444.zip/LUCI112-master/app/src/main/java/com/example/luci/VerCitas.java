package com.example.luci;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class VerCitas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_citas);
    }
}