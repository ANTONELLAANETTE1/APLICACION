package com.example.luci;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CrearCuenta extends AppCompatActivity {
    //Validar rut y largo de contraseña
    private Button btnr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_cuenta);

        btnr = (Button) findViewById(R.id.btnr);

        //Redirección del botón ingresar (btnr)-----------------------------------------------------

        /* Funcionalidades dentro del Activity:
        * Redireccionar al menú de acciones
        * Registrar información en la base de datos
        * */
        btnr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CrearCuenta.this, MenuAcciones.class);
                startActivity(i);
            }
        });
    }
}