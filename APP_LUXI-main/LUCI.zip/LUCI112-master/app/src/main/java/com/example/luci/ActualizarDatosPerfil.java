package com.example.luci;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ActualizarDatosPerfil extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actualizar_datos_perfil);
    }

    /* Funcionalidades del Activity:
    * Los Botones actualizan los datos del paciente (solo esos datos)
    * Los datos solo podrán cambiarse cada vez que el paciente lo requiera en cualquier momento, las veces que quiera
    * Validar campos vacíos, gmail, cantidad de numeros de telefono (9 números).
    * Avisar que la actualización de datos es correcta
    *
    *
    * **/

}