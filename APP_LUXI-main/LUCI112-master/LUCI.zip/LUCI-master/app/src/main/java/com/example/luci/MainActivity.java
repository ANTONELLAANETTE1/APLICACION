package com.example.luci;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.Firebase;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.checkerframework.checker.nullness.qual.NonNull;

public class MainActivity extends AppCompatActivity {
    private TextView et1;
    private TextView et2;
    private Button btncc;
    private Button btni;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    //Login ------------------------------------------------------------------------------------------
    private void login(){
        Toast.makeText(MainActivity.this, "intentando login", Toast.LENGTH_SHORT).show();
        databaseReference.child("Usuario").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot objSnaptshot : dataSnapshot.getChildren()){
                    Usuarios u = objSnaptshot.getValue(Usuarios.class);
                    if(et1.getText().toString().equals(u.getRut())){
                        if (et2.getText().toString().equals(u.getPass())){
                            Intent i = new Intent(MainActivity.this, MenuAcciones.class);
                            startActivity(i);
                        }
                        else{
                            Toast.makeText(MainActivity.this, "Inténtelo denuevo porfavor :)", Toast.LENGTH_SHORT).show();
                        }

                    }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    //Fin Login

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btncc = (Button) findViewById(R.id.btncc);
        btni = (Button) findViewById(R.id.btni);
        inicializarFirebase();
        //Redirección del botón Crear cuenta (btncc) -----------------------------------------------

        btncc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, CrearCuenta.class);
                startActivity(i);
            }
        });

        //Redirección del botón ingresar (btni)-----------------------------------------------------
        btni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login();
            }
        });
    }

    private void inicializarFirebase (){
        FirebaseApp.initializeApp(this);
        firebaseDatabase = firebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }

}