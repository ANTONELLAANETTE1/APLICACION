package com.example.luci;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MenuAcciones extends AppCompatActivity {

    private Button btnperfil;
    private Button btncita;
    private Button btninfo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_acciones);

        btnperfil = (Button) findViewById(R.id.btnperfil);
        btncita = (Button) findViewById(R.id.btncita);
        btninfo = (Button) findViewById(R.id.btninfo);

        //Redirección del botón ingresar (btnperfil)-----------------------------------------------------
        btnperfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MenuAcciones.this, PerfilPersonal.class);
                startActivity(i);
            }
        });
        //Redirección del botón ingresar (btncita)-----------------------------------------------------
        btncita.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MenuAcciones.this, AgendarCita.class);
                startActivity(i);
            }
        });
        //Redirección del botón ingresar (btninfo)-----------------------------------------------------
        btninfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MenuAcciones.this, PreguntasFrecuentes.class);
                startActivity(i);
            }
        });
    }
}